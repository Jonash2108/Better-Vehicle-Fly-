--[  ███████╗██╗  ██╗ ██╗██████╗   ]--
--[  ██╔════╝██║ ██╔╝███║██╔══██╗  ]--
--[  ███████╗█████╔╝ ╚██║██║  ██║  ]--
--[  ╚════██║██╔═██╗  ██║██║  ██║  ]--
--[  ███████║██║  ██╗ ██║██████╔╝  ]--
--[  ╚══════╝╚═╝  ╚═╝ ╚═╝╚═════╝   ]--
g_lua.register()

pid = PLAYER.PLAYER_ID()
ppid = PLAYER.PLAYER_PED_ID()
rot = ENTITY.GET_ENTITY_ROTATION(PLAYER.GET_PLAYER_VEHICLE(PLAYER.PLAYER_ID()), 5)
anyVehicle = PLAYER.IS_PLAYER_IN_ANY_VEHICLE(PLAYER.PLAYER_ID())
KeyPress = CONTROL.IS_CONTROL_PRESSED
ApplyForceCenter = ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS
AppylyForce = ENTITY.APPLY_FORCE_TO_ENTITY
maxVehicle = POOL.GET_MAX_VEHICLES()
rqConEntity = NETWORK.REQUEST_CONTROL_OF_ENTITY

g_gui.add_toggle("vehicle_options", "NoClip Fly", "WASD: Moving | CapsLock: Up | Shift: Speed | Ctrl: Down | Mouse: Rotate", function(on) noclip=on Noclip() end) -- Noclip vehicle Fly
g_gui.add_toggle("vehicle_options", "SportMode Fly [WIP]", "WASD: Moving | CapsLock: Up | Shift: Speed | Ctrl: Down | Mouse: Rotate", function(on) sportmode=on SportMode() end) -- Noclip vehicle Fly
g_gui.add_toggle("vehicle_options", "Glide Fly", function(on) hover=on Hover() end) -- New Glide Fly
g_gui.add_toggle("vehicle_options", "Camera Fly", "Hold Shift to Fly faster, use Mouse for direction.", function(on) camfly=on CamFly() end) -- Can also be used to troll, since you c

function rqCtrl(entity, t)
    if ENTITY.DOES_ENTITY_EXIST(entity) then
        netId = NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)
        NETWORK.SET_NETWORK_ID_CAN_MIGRATE(netId, true)
        t = t or 0.03
        time = os.time() + t
        while not NETWORK.HAS_CONTROL_OF_ENTITY(entity) do
            NETWORK.REQUEST_CONTROL_OF_ENTITY(entity)
            SYSTEM.WAIT()
            if os.time() > time then
                return NETWORK.HAS_CONTROL_OF_ENTITY(entity)
            end
        end
        return NETWORK.HAS_CONTROL_OF_ENTITY(entity)
    end
    return false
end

function rqCtrl(entity, t) -- Request Control
    if ENTITY.DOES_ENTITY_EXIST(entity) then
        netId = NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)
        NETWORK.SET_NETWORK_ID_CAN_MIGRATE(netId, true)
        t = t or 0.03
        time = os.time() + t
        while not NETWORK.HAS_CONTROL_OF_ENTITY(entity) do
            rqConEntity(entity)
            SYSTEM.WAIT()
            if os.time() > time then
                return NETWORK.HAS_CONTROL_OF_ENTITY(entity)
            end
        end
        return NETWORK.HAS_CONTROL_OF_ENTITY(entity)
    end
    return false
end

function addBlip(entity, blipSprite, colour) -- Blip, Blop, Blup
    local blip_ptr = g_memory.allocate(4)
    local blip = UI.ADD_BLIP_FOR_ENTITY(entity)
    g_memory.write_int(blip_ptr, blip)
    UI.SET_BLIP_SPRITE(blip, blipSprite)
    UI.SET_BLIP_COLOUR(blip, colour)
    local netId = NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)
    g_memory.free(blip_ptr)
end

function is_veh_personal(veh) -- Check if Vehicle is a Personal Vehicle
    local blip = UI.GET_BLIP_FROM_ENTITY(veh)
    bliptype = UI.GET_BLIP_INFO_ID_TYPE(blip)
    if tonumber(bliptype) == 1 then
        return true
    else
        return false
    end
end

function TeleportSelf(pos) -- Teleport yourself, self explanatory from the name, duh
    local entity = ppid()
    if anyVehicle then
        entity = PLAYER.GET_PLAYER_VEHICLE(PLAYER.PLAYER_ID())
    end
    if rqCtrl(entity, 0.5) then
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z)
        if pos.h then
            ENTITY.SET_ENTITY_HEADING(entity, pos.h)
        end
    end
    
end

function getAllVehs(radius) -- Get All Vehicles in your Radius
    local me, vehs, allvehs = PLAYER.PLAYER_PED_ID(), {}, maxVehicle
    for i = 0, allvehs do
        local veh = POOL.GET_VEHICLE_AT_INDEX(i)
        if ENTITY.DOES_ENTITY_EXIST(veh) then
            if radius == nil then
                table.insert(vehs, veh)
            elseif radius > getDistanceToEntity(me, veh) then
                table.insert(vehs, veh)
            end
        end

    end

    return vehs
end

function RotationToDirection(rotation) -- Rotate to Camera View, i think, idk it's skidded dude
    local ret = {z = rotation.z * 0.0174532924,x = rotation.x * 0.0174532924,}
    local absx=math.abs(math.cos(ret.x))
    local dir = {x = -math.sin(ret.z) * absx,y = math.cos(ret.z) * absx,z = math.sin(ret.x),} return dir
end

function Noclip()

    if noclip == true then

        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(PLAYER.PLAYER_ID()) then
            Vehicle = PLAYER.GET_PLAYER_VEHICLE(PLAYER.PLAYER_ID())
            rqCtrl(Vehicle)
            ENTITY.FREEZE_ENTITY(Vehicle, true)
            ENTITY.SET_ENTITY_COLLISION(Vehicle, false, false)
        end
    end
    SYSTEM.WAIT(10)
    if noclip == false then
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(PLAYER.PLAYER_ID()) then
            Vehicle = PLAYER.GET_PLAYER_VEHICLE(PLAYER.PLAYER_ID())
            rqCtrl(Vehicle)
            ENTITY.FREEZE_ENTITY(Vehicle, false)
            ENTITY.SET_ENTITY_COLLISION(Vehicle, true, true)
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(Vehicle, 0.000001)
        end
    end
    SYSTEM.WAIT(10)
    while true do
        if noclip == false then break end
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(PLAYER.PLAYER_ID()) then
            Vehicle = PLAYER.GET_PLAYER_VEHICLE(PLAYER.PLAYER_ID())
            NETWORK.REQUEST_CONTROL_OF_ENTITY(Vehicle)
            ENTITY.FREEZE_ENTITY(Vehicle, true)
            local rot = CAM.GET_GAMEPLAY_CAM_ROT(5)
            ENTITY.SET_ENTITY_ROTATION(Vehicle, rot.x, rot.y, rot.z, 5, true)
            if CONTROL.IS_CONTROL_PRESSED(2, 131) then
                multiplier = 10
            else
                multiplier = 1
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 87) then
                posW = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(Vehicle, 0, 1 * multiplier, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Vehicle, posW.x, posW.y, posW.z)
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 88) then
                posS = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(Vehicle, 0, -1 * multiplier, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Vehicle, posS.x, posS.y, posS.z)
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 89) then
                posA = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(Vehicle, -1 * multiplier, 0, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Vehicle, posA.x, posA.y, posA.z)
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 90) then
                posD = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(Vehicle, 1 * multiplier, 0, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Vehicle, posD.x, posD.y, posD.z)
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 137) then
                posUp = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(Vehicle, 0, 0, 1 * multiplier)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Vehicle, posUp.x, posUp.y, posUp.z)
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 132) then
                posDow = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(Vehicle, 0, 0, -1 * multiplier)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Vehicle, posDow.x, posDow.y, posDow.z)
            end
        end
        SYSTEM.WAIT()
    end
end

function SportMode() -- Function for Better SportMode Fly [NEED TO BE TESTED WIP]
    if sportmode == true then
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(pid) then
            vehicle = PLAYER.GET_PLAYER_VEHICLE(pid)
            rqCtrl(vehicle)
            ENTITY.SET_ENTITY_COLLISION(vehicle, true, true)
        end
    end
    SYSTEM.WAIT(10)
    if sportmode == false then
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(pid) then
            vehicle = PLAYER.GET_PLAYER_VEHICLE(pid)
            rqCtrl(vehicle)
            ENTITY.SET_ENTITY_COLLISION(vehicle, true, true)
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(vehicle, 0.000001)
        end
    end
    SYSTEM.WAIT(10)
    while true do
        if sportmode == false then break end
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(pid) then
            Vehicle = PLAYER.GET_PLAYER_VEHICLE(pid)
            rqConEntity(vehicle)
            ENTITY.SET_ENTITY_COLLISION(vehicle, true, true)
            local rot = CAM.GET_GAMEPLAY_CAM_ROT(5)
            ENTITY.SET_ENTITY_ROTATION(vehicle, rot.x, rot.y, rot.z, 5, true)
            if KeyPress(2, 131) then
                multiplier = 5
            else
                multiplier = 1
            end
            if KeyPress(2, 87) then
                posW = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(vehicle, 0, 1 * multiplier, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, posW.x, posW.y, posW.z)
            end
            if KeyPress(2, 88) then
                posS = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(vehicle, 0, -1 * multiplier, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, posS.x, posS.y, posS.z)
            end
            if KeyPress(2, 89) then
                posA = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(vehicle, -1 * multiplier, 0, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, posA.x, posA.y, posA.z)
            end
            if KeyPress(2, 90) then
                posD = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(vehicle, 1 * multiplier, 0, 0)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, posD.x, posD.y, posD.z)
            end
            if CONTROL.IS_CONTROL_PRESSED(2, 137) then
                posUp = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(vehicle, 0, 0, 1 * multiplier)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, posUp.x, posUp.y, posUp.z)
            end
            if KeyPress(2, 132) then
                posDow = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(vehicle, 0, 0, -1 * multiplier)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, posDow.x, posDow.y, posDow.z)
            end
        end
        SYSTEM.WAIT()
    end
end

function Hover() -- Glide Fly
    while hover do
        local vehicle = PLAYER.GET_PLAYER_VEHICLE(pid)
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(pid) then
            ApplyForceCenter(vehicle, 0, 0, 0, 27, true, true, true, false)
        else
            ApplyForceCenter(vehicle, 0, 0, 0, 0, true, true, true, false)
        end
        SYSTEM.WAIT()
    end
end

function CamFly()  -- Camfly which also can be used for trolling
    while camfly do
        if not KeyPress(0, 76) then goto continue 
        end 
        if PLAYER.IS_PLAYER_IN_ANY_VEHICLE(pid) then 
            local vehicle=PLAYER.GET_PLAYER_VEHICLE(pid) 
            local mult=1 
            if KeyPress(0, 21) then 
                mult=20 
            end 
            local dir=RotationToDirection(CAM.GET_GAMEPLAY_CAM_ROT(2)) rqConEntity(vehicle) ENTITY.SET_ENTITY_VELOCITY(vehicle,dir.x * 10 * mult,dir.y * 10 * mult,dir.z * 10 * mult) 
        end 
        ::continue:: 
        SYSTEM.WAIT()
    end
end

while g_isRunning do

    if VehicleBrakeTog then
        vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.GET_PLAYER_PED(PLAYER.PLAYER_ID()), true)
        if CONTROL.IS_CONTROL_PRESSED(22, 22) then
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(vehicle, 0)
        end
    end
    
    SYSTEM.WAIT(10)
end

g_lua.unregister()